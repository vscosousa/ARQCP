 #ifndef ASM_H
  #define ASM_H
  long  sum_and_subtract(void);
#endif
