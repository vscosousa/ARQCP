#ifndef ASM_H 
#define ASM_H 
short *  vec_search(void); 
#endif 

