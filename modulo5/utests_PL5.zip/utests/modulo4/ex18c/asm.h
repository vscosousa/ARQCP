#ifndef ASM_H 
#define ASM_H 
void changes( int  * p ); 
void changes_vec( int  * p , int num ); 
#endif 

