#ifndef ASM_H 
#define ASM_H 
int call_incr(short w); 
#endif 

