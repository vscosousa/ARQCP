#ifndef ASM_H 
#define ASM_H 
int join_bits( int a, int b, int pos); 
int mixed_sum( int a, int b, int pos); 
#endif 

