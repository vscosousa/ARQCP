#ifndef FUNC_H 
#define FUNC_H 
void add_byte( char x ,  int  * p1 , int  *p2  ); 
#endif 

