#ifndef FUNC_H 
#define FUNC_H 
void changes( int  * p ); 
#endif 

