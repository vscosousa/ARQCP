#ifndef ASM_H 
#define ASM_H 
int sum_smaller(int x,int y, int* p); 
#endif 

