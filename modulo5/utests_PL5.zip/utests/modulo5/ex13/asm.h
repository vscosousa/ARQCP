#ifndef ASM_H
#define ASM_H 
int ** new_matrix (int lines, int columns);
int count_odd_matrix(int **m, int y, int k) ;
#endif
