#ifndef ASM_H 
#define ASM_H 
#include "struct.h" 
char return_unionB_b(structA **matrix, int i, int j);
#endif 

