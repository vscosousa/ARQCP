#ifndef FUNC_H 
#define FUNC_H 
#include "struct.h" 
structA ** zxc_new_matrix (int lines, int columns); 
#endif 

