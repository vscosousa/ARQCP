#ifndef ASM_H
#define ASM_H 
int ** new_matrix (int lines, int columns);
int find_matrix(int **m, int y, int k, int num);
#endif
