#ifndef STRUCT_H
#define STRUCT_H 

typedef struct{
    short n_students;
    unsigned short *individual_grades;
}group;

#endif 
