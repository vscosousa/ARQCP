#ifndef ASM_H
#define ASM_H 
int ** new_matrix (int lines, int columns);
int ** add_matrixes(int **a , int **b , int y , int k)  ; 
#endif
