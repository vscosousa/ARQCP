#ifndef ASM_H 
#define ASM_H 
long cube(int x); 
#endif 

