#ifndef FUNC_H 
#define FUNC_H 
int reset_bit( int * ptr, int pos); 
void  reset_2bits( int * ptr, int pos); 
#endif 

