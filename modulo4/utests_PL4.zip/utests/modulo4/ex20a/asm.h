#ifndef FUNC_H 
#define FUNC_H 
int sum_multiples_x( char *p , int x  ); 
#endif 

