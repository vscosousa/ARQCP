#ifndef ASM_H 
#define ASM_H 
int count_odd(char *p,int num); 
#endif 

