#ifndef ASM_H 
#define ASM_H 
int test_equal(char *p1,char *p2); 
#endif 

