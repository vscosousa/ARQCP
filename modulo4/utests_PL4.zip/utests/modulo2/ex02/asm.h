 #ifndef ASM_H
  #define ASM_H
  int sum(void);
#endif
