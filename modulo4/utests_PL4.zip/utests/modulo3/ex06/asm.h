#ifndef ASM_H 
#define ASM_H 
int encrypt(void); 
#endif 

