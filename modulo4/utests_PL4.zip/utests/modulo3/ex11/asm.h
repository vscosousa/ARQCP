#ifndef ASM_H 
#define ASM_H 
int vec_greater10(void); 
#endif 

