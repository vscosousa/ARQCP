#ifndef ASM_H 
#define ASM_H 
unsigned char  vec_zero(void); 
#endif 

