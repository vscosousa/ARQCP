#ifndef ASM_H 
#define ASM_H 
void  frequencies( float * grades , int n , int * freq ); 
#endif 

