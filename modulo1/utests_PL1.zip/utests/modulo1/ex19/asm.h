#ifndef ASM_H 
#define ASM_H 
char* find_word(char* str, char* word ); 
#endif 

