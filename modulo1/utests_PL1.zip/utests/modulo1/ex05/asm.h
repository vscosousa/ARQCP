#ifndef ASM_H 
#define ASM_H 
void upper2(char *str);
#endif 

