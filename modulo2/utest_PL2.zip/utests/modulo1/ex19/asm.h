#ifndef ASM_H 
#define ASM_H 
char* find_word(char* word, char* str ); 
#endif 

