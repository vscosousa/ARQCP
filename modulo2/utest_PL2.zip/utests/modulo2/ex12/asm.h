 #ifndef ASM_H
  #define ASM_H
  char isMultiple(void);
#endif
