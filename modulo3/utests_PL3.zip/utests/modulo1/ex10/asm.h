#ifndef ASM_H 
#define ASM_H 
int odd_sum( int *p ); 
#endif 

