#ifndef ASM_H 
#define ASM_H 
int where_is (char * str , char c , int * p); 
#endif 

