 #ifndef ASM_H
  #define ASM_H
  int sum_v2(void);
#endif
