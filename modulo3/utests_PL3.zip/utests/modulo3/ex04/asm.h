#ifndef ASM_H 
#define ASM_H 
void  vec_add_two(void); 
#endif 

