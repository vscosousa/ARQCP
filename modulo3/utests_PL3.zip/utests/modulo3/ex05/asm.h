#ifndef ASM_H 
#define ASM_H 
long vec_sum(void); 
long vec_avg(void); 
#endif 

