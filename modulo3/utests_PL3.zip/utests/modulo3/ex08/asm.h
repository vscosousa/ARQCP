#ifndef ASM_H 
#define ASM_H 
long test_even(void); 
long vec_sum_even(void); 
#endif 

