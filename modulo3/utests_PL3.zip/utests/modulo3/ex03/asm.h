#ifndef ASM_H 
#define ASM_H 
void str_copy_porto2(void); 
#endif 

